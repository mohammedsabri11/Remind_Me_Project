package com.saudi.remindme.statedialog;

// Interface for dialog listeners
public interface DialogListener {
    void onDialogDismissed();
}