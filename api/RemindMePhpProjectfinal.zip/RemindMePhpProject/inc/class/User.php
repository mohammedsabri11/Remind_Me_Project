<?php

class User  {

    

    public function consultantRegister(UserModel $usermodel,$certificateImagePath,$speciality,$experience) {
        $db = new Database();

        // Check if email or username already exists
        if ($db->checkDuplicate('mainuser', 'email', $usermodel->getEmail() )) {
            $response = array("status" => FALSE,"msg" => "Email already exists!");
            $this->sendResponse($response );
            return ;
        }

       

        // Insert data into mainuser table
        $sql = "INSERT INTO mainuser (fullname,gender,dob,password, email,mobile, usertype) VALUES ('" . $usermodel->getFullName(). "','" .  $usermodel->getGender(). "','" .  $usermodel->getDOB()  . "','" .$usermodel->getPassword()  . "','" .  $usermodel->getEmail() . "','" . $usermodel->getPhone() . "','" . $usermodel->getUserType() . "')";
        $result = $db->executeQuery($sql);

        if ($result) {
            // Get the newly inserted muserid
            $consultantId = $db->conn->insert_id;

            // Insert data into consultant table
            $sql = "INSERT INTO consultant (consultantId,speciality,experience) VALUES ('$consultantId','$speciality','$experience')";
            $result = $db->executeQuery($sql);

            if ($result) {
               

                // Insert data into certificate table
                $sql = "INSERT INTO certificate (consultantId, certificateImage) VALUES ('$consultantId', '$certificateImagePath')";
                $result = $db->executeQuery($sql);

                if ($result) {
                    $response = array("status" => TRUE,"msg" => "Data inserted successfully!");
                   
                 
                } else {
                
                    $response = array("status" => FALSE,"msg" => "Failed to insert data into certificate table!");
                }
            } else {
                
                $response = array("status" => FALSE,"msg" => "Failed to insert data into consultant table!");
            }
        } else {
            
            $response = array("status" => FALSE,"msg" => "Failed to insert data into mainuser table!");
        }
        $this->sendResponse($response );
    }

    public function updateConsultant($ConsultantId,$shortDescription,$profile) {
        $db = new Database();
        $active=FALSE;
        // Update isactive field in mainuser table
        $sql = "UPDATE consultant SET shortDescription = '$shortDescription' , profile = '$profile' where consultantId='$ConsultantId'";
        $result = $db->executeQuery($sql);

        if ($result) {
          
            $response = array("status" => TRUE, "msg" =>  "profile updated successfully!"); 
        } else {
         
            $response = array("status" => FALSE, "msg" =>  "Failed to update profile!"); 
        }
        $this->sendResponse($response );
    }
    public function updateConsultant2($ConsultantId,$shortDescription) {
        $db = new Database();
        $active=FALSE;
        // Update isactive field in mainuser table
        $sql = "UPDATE consultant SET shortDescription = '$shortDescription'  where consultantId='$ConsultantId'";
        $result = $db->executeQuery($sql);

        if ($result) {
          
            $response = array("status" => TRUE, "msg" =>  "profile updated successfully!"); 
        } else {
         
            $response = array("status" => FALSE, "msg" =>  "Failed to update profile!"); 
        }
        $this->sendResponse($response );
    }

    public function userRegister(UserModel $usermodel,$careProviderName,$healtStatusDetails) {
   
        $db = new Database();

        if ($db->checkDuplicate('mainuser', 'email', $usermodel->getEmail() )) {
            $response = array("status" => FALSE,"msg" => "Email already exists!");
            $this->sendResponse($response );
            return ;
        }

      

        // Insert data into mainuser table
        $sql = "INSERT INTO mainuser (fullname,gender,dob,password, email,mobile, usertype) VALUES ('" . $usermodel->getFullName(). "','" .  $usermodel->getGender(). "','" .  $usermodel->getDOB()  . "','" .$usermodel->getPassword()  . "','" .  $usermodel->getEmail() . "','" . $usermodel->getPhone() . "','" . $usermodel->getUserType() . "')";
        $result = $db->executeQuery($sql);

        if ($result) {
            // Get the newly inserted muserid
            $muserid = $db->conn->insert_id;

            // Insert data into tuser table
          
            $sql = "INSERT INTO tuser (userid,careprovidername,healtstatusdetails) VALUES ('$muserid','$careProviderName','$healtStatusDetails')";
            $result = $db->executeQuery($sql);

            if ($result) {
                $response = array("status" => TRUE,"msg" => "Data inserted successfully!");
            } else {
              
                         
                $response = array("status" => FALSE,"msg" => "Failed to insert data into tuser table!");
            }
        } else {
            $response = array("status" => FALSE,"msg" => "Failed to insert data into mainuser table!");
        }
        $this->sendResponse($response );
    }

    public function loginUser($email, $password) {
        $db = new Database();

        // Check if the user exists
        $sql = "SELECT * FROM mainuser WHERE email = '$email' AND password = '$password'";
        $result = $db->conn->query($sql);

        if ($result->num_rows > 0) {
            // User found, retrieve user data
            $user = $result->fetch_assoc();

            // Convert user data to JSON
        
            $response = array("status" => TRUE,"profile" =>  $user);
            
        } else {
           
            $response = array("status" => FALSE,"msg" => "Invalid email or password!");
        }
        $this->sendResponse($response );
    }



    public function sendResponse($response) {
        header('Content-type: application/json');
        $response = json_encode($response);
        echo $response;
    }
//###################################################################################
}