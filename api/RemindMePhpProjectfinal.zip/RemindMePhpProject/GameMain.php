<?php
require_once(dirname(__FILE__) . '/conf/config.php');
//cho  '/conf/config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    switch ($_POST['op']) {
        
        case "LoadConsultantGame":   
            $game = new Game();

           // Retrieve games by consultantId
            $game->consultantId = $_POST["consultantId"];
            $game->retrieveGamesByConsultantId();
            break;
        case "Add":   
            $game = new Game('',$_POST["name"],$_POST["description"] ,$_POST["link"],$_POST["consultantId"]);

           $game->insertGame();
           
          
      
            break;

        case "Edit":     
            $game = new Game($_POST["gameId"],$_POST["name"],$_POST["description"] ,$_POST["link"],$_POST["consultantId"]);

            // Edit game
       
            $game->editGame();
            break;
            
        case "Delete":
            $game = new Game();
          
           $game->gameid = $_POST["gameId"];
           $game->consultantId = $_POST["consultantId"];
            // Delete game
           $game->deleteGame();


            break;
        case "LoadMyGameList":   
            $game = new Game();
    
            // Retrieve games by userId
     
                $game->retrieveGamesByUserId( $_POST["userId"]);
            break;
        case "AddGameToUser":   
           $game = new Game();
 
            $game->addGameToUser($_POST["gameId"], $_POST["userId"]);
            break;

  
        default:
            break;
    }
    
   }else if ($_SERVER['REQUEST_METHOD'] == "GET") {

    switch ($_GET['op']) {
        
        case "LoadConsultantGame":   
            $game = new Game();

           // Retrieve games by consultantId
            $game->consultantId = $_GET["consultantId"];
            $game->retrieveGamesByConsultantId();
            break;
      
        case "LoadMyGameList":   
            $game = new Game();
    
            // Retrieve games by userId
     
                $game->retrieveGamesByUserId( $_GET["userId"]);
            break;
       
  
        default:
            break;
    } } else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>