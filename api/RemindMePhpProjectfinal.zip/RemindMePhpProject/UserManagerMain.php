<?php
require_once(dirname(__FILE__) . '/conf/config.php');
//cho  '/conf/config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    switch ($_POST['op']) {
       
       
        case "ActivateUser":   
            $user = new UserManager();
            $user->activateUser($_POST['userId']  );
            break;
        case "DeActivateUser":
            $user = new UserManager();
            $user->deActivateUser($_POST['userId'] );
            break;

     
        default:
            break;
    }
    
   }
   else if ($_SERVER['REQUEST_METHOD'] == "GET") {

    switch ($_GET['op']) {
        
        case "LoadConsultant":   
            $user = new UserManager();
           $user->loadConsultants( );
       
           break;


       case "LoadUser":     
           $user = new UserManager();
           $user->loadUsers( );
           break;
           
           case "LoadConsultantList":   
            $user = new UserManager();
            $user->LoadConsultantList( );
           
               break;
  
        default:
            break;
    }
 } 
    else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>