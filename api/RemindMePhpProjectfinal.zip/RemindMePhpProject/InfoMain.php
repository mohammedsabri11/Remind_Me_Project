<?php
require_once(dirname(__FILE__) . '/conf/config.php');


  if ($_SERVER['REQUEST_METHOD'] == "GET") {

    switch ($_GET['op']) {
        
       
        
        case "LoadMyInfo":   
            $info = new Info();

           // Retrieve Infos by userId
           
           
            $info->getInfo();
    
           
           break;
        default:
            break;
    }
 }
   else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>