<?php


require_once(dirname(dirname(__FILE__)) . '/inc/class/Database.php');
require_once(dirname(dirname(__FILE__)) . '/inc/class/Query.php');
require_once(dirname(dirname(__FILE__)) . '/inc/class/User.php'); 
require_once(dirname(dirname(__FILE__)) . '/inc/class/Game.php');
require_once(dirname(dirname(__FILE__)) . '/inc/class/Info.php'); 
require_once(dirname(dirname(__FILE__)) . '/inc/class/Reminder.php');
require_once(dirname(dirname(__FILE__)) . '/inc/class/UserManager.php');

require_once(dirname(dirname(__FILE__)) . '/inc/model/UserModel.php');
require_once(dirname(dirname(__FILE__)) . '/inc/class/Evaluation.php');

?>