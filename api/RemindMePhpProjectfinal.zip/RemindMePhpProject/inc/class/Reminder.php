<?php

class Reminder {
    public $reminderid;
    public $datetime;
    public $appointmentdetails;
    public $userid;

    public function __construct( $datetime = null, $appointmentdetails = null, $userid = null) {
       
        $this->datetime = $datetime;
        $this->appointmentdetails = $appointmentdetails;
        $this->userid = $userid;
    }

    public function insertReminder() {
        $db = new Database();

        // Insert new reminder
        $sql = "INSERT INTO reminder (datetime, appointmentdetails, userid) VALUES ('$this->datetime', '$this->appointmentdetails', '$this->userid')";
        $result = $db->executeQuery($sql);

       
        if ($result) {
        
            $response = array("status" => TRUE,"msg" => "Reminder added successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to add reminder!");
        }
      
        $this->sendResponse($response );
    }

    public function retrieveMyReminder() {
        $db = new Database();

        // Retrieve reminders by userId if datetime is not in the past
        $sql = "SELECT * FROM reminder WHERE userid = '$this->userid' AND datetime > NOW()";
        $result = $db->conn->query($sql);

        $reminders = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $reminders[] = $row;
            }
        }

        $response = array("status" => TRUE, "ReminderList" =>$reminders);    
        

        $this->sendResponse($response );
    }

    public function deleteReminder() {
        $db = new Database();

        // Delete data from game table
        $sql = "DELETE FROM reminder WHERE reminderid = '$this->reminderid' AND userid = '$this->userid'";
        $result = $db->executeQuery($sql);

        if ($result) {
        
            $response = array("status" => TRUE,"msg" => "Reminder deleted successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to delete Reminder!");
        }
        $this->sendResponse($response );
    }

    public function sendResponse($response) {
        header('Content-type: application/json');
          // Convert  data to JSON
        $response = json_encode($response);
        echo $response;
        
    }
}