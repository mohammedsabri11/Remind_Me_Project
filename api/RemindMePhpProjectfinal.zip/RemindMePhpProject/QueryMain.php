<?php
require_once(dirname(__FILE__) . '/conf/config.php');
//cho  '/conf/config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    switch ($_POST['op']) {
        
      
           

        case "Add":   
            $query = new Query( null,  null, $_POST["querytext"] ,  null,  null, $_POST["consultantId"] ,$_POST["userId"] );
          
      
            $query-> addQuery();
           
          
      
            break;

       
        case "Reply":
            $query = new Query();
            $query->userid = $_POST["userId"] ;
           $query->consultantId = $_POST["consultantId"] ;
           $query->queryid = $_POST["queryId"] ;
           $query->insertReply( $_POST["reply"]);

            break;
        
     case "Delete":
        $query = new Query();
        $query->userid = $_POST["userId"] ;
        $query->queryid = $_POST["queryId"] ;
        $query->consultantId = $_POST["consultantId"] ;
        $query->deleteQuery();
         
           
    
    
                break;

        default:
            break;
    }
    
   } 
   else if ($_SERVER['REQUEST_METHOD'] == "GET") {

    switch ($_GET['op']) {
          
       

        
        case "LoadConsultantQuery":   
            $query = new Query();

           // Retrieve games by consultantId
            $query->consultantId= $_GET["consultantId"] ;
           
            $query->retrieveQueriesByConsultantId();

            break;

            case "LoadQueries":   
                $query = new Query();
    
               // Retrieve Query by UserId
           
                $query->userid = $_GET["userId"];
                $query->consultantId= $_GET["consultantId"] ;
                $query->retrieveAllQueries();
        
                
               break;

      
           case "LoadUsers":   
            $query = new Query();

           // Retrieve games by consultantId
            //$query->consultantId= $_GET["consultantId"] ;
           
            $query->retrieveUsers($_GET["consultantId"]);

            break;

              
        case "LoadConsultants":   
            $query = new Query();

           // Retrieve Query by UserId
       
      
            $query->retrieveConsultants($_GET["userId"]);
    
            
           break;
  
        default:
            break;
    }
 } 
   else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>