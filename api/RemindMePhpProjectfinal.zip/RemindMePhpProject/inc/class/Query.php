<?php

class Query {
    public $queryid;
    public $querydate;
    public $querytext;
    public $queryreply;
    public $replydate;
    public $consultantId;
    public $userid;

    public function __construct($queryid = null, $querydate = null, $querytext = null, $queryreply = null, $replydate = null, $consultantId = null, $userid = null) {
        $this->queryid = $queryid;
        $this->querydate = $querydate;
        $this->querytext = $querytext;
        $this->queryreply = $queryreply;
        $this->replydate = $replydate;
        $this->consultantId = $consultantId;
        $this->userid = $userid;
    }

    /* public function setConsultantId(  $consultantId ) {
      
        $this->consultantId = $consultantId;
      
    }
    public function setUserId(  $userid ) {
      
        $this->userid = $userid;
      
    }
    public function setQueryId(  $queryid ) {
      
        $this->queryid = $queryid;
      
    } */
    
    public function addQuery() {
        $db = new Database();

        // Insert data into    query table
        $sql = "INSERT INTO query (querytext,querydate, userid,consultantId) VALUES ('$this->querytext',NOW(),'$this->userid', '$this->consultantId')";
        $result = $db->executeQuery($sql);

        if ($result) {
            $this->retrieveAllQueries();
           // $response = array("status" => TRUE,"msg" => "Query added successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to add query!");
            $this->sendResponse($response );
        }
       
    }

    public function deleteQuery() {
        $db = new Database();

        // Delete data from game table
        $sql = "DELETE FROM query WHERE queryid = '$this->queryid' AND userid = '$this->userid'";
        $result = $db->executeQuery($sql);

        if ($result) {
            $this->retrieveAllQueries();
          //  $response = array("status" => TRUE,"msg" => "Query deleted successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to delete Query!");
            $this->sendResponse($response );
        }
       
    }


    public function insertReply($reply) {
        $db = new Database();

        // Update query with reply
        $sql = "UPDATE query SET queryreply = '$reply', replydate = NOW() WHERE queryid = '$this->queryid' AND consultantId = '$this->consultantId'";
        $result = $db->executeQuery($sql);

        
        if ($result) {
            $this->retrieveAllQueries();
        //    $response = array("status" => TRUE,"msg" => "Reply added successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to add reply!");
            $this->sendResponse($response );
        }
      
       
    }

    public function retrieveQueriesByConsultantId() {
        $db = new Database();

        // Retrieve queries by consultantId
        $sql = "SELECT query.*,mainuser.fullname FROM query  LEFT JOIN tuser ON tuser.userid=query.userid   LEFT JOIN mainuser ON tuser.userid=mainuser.muserid WHERE query.consultantId = '$this->consultantId' and queryreply IS NOT NULL";
      
        $result = $db->conn->query($sql);

        $queries = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $queries[] = $row;
            }
        }

        $response = array("status" => TRUE, "QueryList" => $queries);  
        

        $this->sendResponse($response );
    }

    public function retrieveConsultants($userid) {
        $db = new Database();

        // Retrieve queries by consultantId
        $sql = " SELECT c.*, mu.*, q.querytext,q.queryreply
        FROM consultant c
        JOIN (
            SELECT q1.*
            FROM query q1
            JOIN (
                SELECT consultantId, MAX(queryDate) AS max_date
                FROM query
                GROUP BY consultantId
            ) q2 ON q1.consultantId = q2.consultantId AND q1.queryDate = q2.max_date
        ) latest_query ON c.consultantId = latest_query.consultantId
        JOIN mainuser mu ON c.consultantId = mu.muserid
        JOIN query q ON latest_query.queryId = q.queryId
        WHERE latest_query.userid = '$userid'";
      
        $result = $db->conn->query($sql);

        $queries = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $queries[] = $row;
            }
        }

        $response = array("status" => TRUE, "Data" => $queries);  
        

        $this->sendResponse($response );
    }

    public function retrieveUsers($consultantId) {
        $db = new Database();

 
        $sql = " SELECT tu.healtstatusdetails, mu.*, q.querytext,q.queryreply
        FROM tuser tu
        JOIN (
            SELECT q1.*
            FROM query q1
            JOIN (
                SELECT userid, MAX(queryDate) AS max_date
                FROM query
                GROUP BY userid
            ) q2 ON q1.userid = q2.userid AND q1.queryDate = q2.max_date
        ) latest_query ON tu.userid = latest_query.userid
        JOIN mainuser mu ON tu.userid = mu.muserid
        JOIN query q ON latest_query.queryId = q.queryId
        WHERE latest_query.consultantId = '$consultantId'";
      

      

        $result = $db->conn->query($sql);

        $queries = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $queries[] = $row;
            }
        }

        $response = array("status" => TRUE, "Data" => $queries);  
        

        $this->sendResponse($response );
    }


    public function retrieveAllQueries() {
        $db = new Database();

        // Retrieve queries by userId
        $sql = "SELECT * FROM query WHERE userid = '$this->userid'  and  query.consultantId = '$this->consultantId'";
        $result = $db->conn->query($sql);

        $queries = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $queries[] = $row;
            }
        }

        $response = array("status" => TRUE, "QueryList" => $queries);    
        

        $this->sendResponse($response );
    }
    public function sendResponse($response) {
        header('Content-type: application/json');
          // Convert  data to JSON
        $response = json_encode($response);
        echo $response;
    }
}