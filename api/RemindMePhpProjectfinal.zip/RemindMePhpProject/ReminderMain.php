<?php
require_once(dirname(__FILE__) . '/conf/config.php');
//cho  '/conf/config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    switch ($_POST['op']) {
        
       


        case "Add":  
            //$_POST["datetime"]
              $datetime=   date("y-m-d H:m:s", strtotime($_POST["datetime"]));
            $reminder = new Reminder($datetime,$_POST["appointmentdetails"],$_POST["userId"]);

            // Insert new reminder

             $reminder->insertReminder();

           
          
      
            break;
            case "Delete":  
                $reminder = new Reminder();

                // Retrieve games by consultantId
                $reminder->reminderid  = $_POST["reminderId"];
                $reminder->userid  = $_POST["userId"];
                 $reminder->deleteReminder();
               
              
          
                break;
       
       

        default:
            break;
    }
    
   }else if ($_SERVER['REQUEST_METHOD'] == "GET") {

    switch ($_GET['op']) {
        
       
      
        
        case "LoadMyReminder":   
            $reminder = new Reminder();

           // Retrieve games by consultantId
           $reminder->userid  = $_GET["userId"];
           
            $reminder->retrieveMyReminder();
    
               // Retrieve My reminder 
           break;
  
        default:
            break;
    }
 } 
  else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>