<?php

class UserManager  {

    public function activateUser($userid) {
        $db = new Database();

         // Update isactive field in mainuser table
         $active=TRUE;
        $sql = "UPDATE mainuser SET isactive = '$active' where muserid='$userid'";
        $result = $db->executeQuery($sql);

        if ($result) {
          
            $response = array("status" => TRUE, "msg" =>  "User activated successfully!"); 
        } else {
         
            $response = array("status" => FALSE, "msg" =>  "Failed to activate user!"); 
        }
        $this->sendResponse($response );
    }

  

    public function deActivateUser($userid) {
        $db = new Database();
        $active='0';
        // Update isactive field in mainuser table
        $sql = "UPDATE mainuser SET isactive = '$active' where muserid='$userid'";
        $result = $db->executeQuery($sql);

        if ($result) {
          
            $response = array("status" => TRUE, "msg" =>  "User deactivated successfully!"); 
        } else {
         
            $response = array("status" => FALSE, "msg" =>  "Failed to deactivate user!"); 
        }
        $this->sendResponse($response );
    }


    public function loadConsultants() {
        $db = new Database();
        $usertype='Consultant';
        // Retrieve games by consultantId mainuser.*,certificateImage
        $sql = "SELECT mainuser.*,consultant.shortDescription, consultant.speciality, consultant.experience, consultant.profile,certificateImage FROM mainuser LEFT JOIN consultant ON consultant.consultantId=mainuser.muserid  LEFT JOIN certificate ON certificate.consultantId=consultant.consultantId WHERE mainuser.usertype = '$usertype'";
        $result = $db->conn->query($sql);

        $consultants = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $consultants[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "ConsultantList" =>  $consultants);  
        

        $this->sendResponse($response );
    }


    public function loadUsers() {
        $db = new Database();
        $usertype='User';
        // Retrieve games by consultantId mainuser.*,certificateImage
        $sql = "SELECT mainuser.*,tuser.* FROM mainuser LEFT JOIN tuser ON tuser.userid=mainuser.muserid  WHERE mainuser.usertype = '$usertype'";
        $result = $db->conn->query($sql);

        $users = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "UserList" =>    $users);  
        

        $this->sendResponse($response );
    }

    public function LoadConsultantProfile($consultantId) {
        $db = new Database();
   
           $sql = "SELECT mainuser.fullname, mainuser.muserid, mainuser.gender, mainuser.mobile, mainuser.dob, consultant.shortDescription, consultant.speciality, consultant.experience, consultant.profile, COUNT(evaluation.consultant_Id) AS evaluation_count FROM mainuser LEFT JOIN consultant ON consultant.consultantId = mainuser.muserid LEFT JOIN evaluation ON evaluation.consultant_Id = consultant.consultantId WHERE mainuser.muserid = '$consultantId' GROUP BY mainuser.muserid";
        $result = $db->conn->query($sql);
        
         $user='';
         if ($result->num_rows > 0) {
            // User found, retrieve user data
            $user = $result->fetch_assoc();

            // Convert user data to JSON
        
           
            
        } 

      return   $user;  
        

      
    }

    public function LoadConsultantList() {
        $db = new Database();
        $usertype='Consultant';
           $sql = "SELECT mainuser.fullname, mainuser.muserid, mainuser.gender, mainuser.mobile, mainuser.dob, consultant.shortDescription, consultant.speciality, consultant.experience, consultant.profile, COUNT(evaluation.consultant_Id) AS evaluation_count FROM mainuser LEFT JOIN consultant ON consultant.consultantId = mainuser.muserid LEFT JOIN evaluation ON evaluation.consultant_Id = consultant.consultantId WHERE mainuser.usertype = '$usertype' GROUP BY mainuser.muserid";
        $result = $db->conn->query($sql);
         $consultants = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $consultants[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "Data" =>  $consultants);  
        

        $this->sendResponse($response );
    }

    public function sendResponse($response) {
        header('Content-type: application/json');
        $response = json_encode($response);
        echo $response;
    }
//###################################################################################
}