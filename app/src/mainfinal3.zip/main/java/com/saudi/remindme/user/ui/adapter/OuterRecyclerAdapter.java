package com.saudi.remindme.user.ui.adapter;

public class OuterRecyclerAdapter {
}
