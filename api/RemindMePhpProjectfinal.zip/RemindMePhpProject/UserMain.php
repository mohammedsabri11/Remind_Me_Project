<?php
require_once(dirname(__FILE__) . '/conf/config.php');
//cho  '/conf/config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    switch ($_POST['op']) {
        case "ConsultantSignUp":   
            $imageName = $_POST["imageName"] . ".jpg";
            $image = $_POST["image"];
            $decodedImage = base64_decode("$image");
            $is_save = file_put_contents("uploads/" .   $imageName, $decodedImage);
            $response = array();
            if ($is_save !== false) {  
            $userModel = new UserModel('', $_POST['fullName'],$_POST['gender'],$_POST['dob'],$_POST['phone'],$_POST['email'], $_POST['password'],$_POST['userType'] );           
            $user = new User();
            $user->consultantRegister($userModel,$imageName,$_POST['speciality'],$_POST['experience'] );
        } else {
            $response['status'] = 0;
            $response['msg'] = "Image failed to upload";
            echo json_encode($response);
        }
            break;

        case "UserSignUp":     
            $userModel = new UserModel('', $_POST['fullName'],$_POST['gender'],$_POST['dob'],$_POST['phone'],$_POST['email'], $_POST['password'],$_POST['userType'] );              
            $user = new User();
            $user->userRegister($userModel,$_POST['careProviderName'],$_POST['healthStatusDetails']);
            break;

        case "ConsultantUpdateProfile":     
            $profileImageName = $_POST["imageName"] . ".jpg";
            $image = $_POST["image"];
            $decodedImage = base64_decode("$image");
            $is_save = file_put_contents("uploads/" . $profileImageName, $decodedImage);
            $response = array();
            if ($is_save !== false) {  
                $user = new User();
                $user->updateConsultant($_POST['consultantId'],$_POST['shortDescription'],$profileImageName);
            } else {
                $response['status'] = 0;
                $response['msg'] = "Image failed to upload";
                echo json_encode($response);
            }
          
            break;
            case "ConsultantUpdateProfile1":     
               
                    $user = new User();
                    $user->updateConsultant2($_POST['consultantId'],$_POST['shortDescription']);
              
              
                break;
            
        case "login":
            $user = new User();
            $user->loginUser($_POST['email'], $_POST['password']); 
            break;

        default:
            break;
    }
    
   } else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>