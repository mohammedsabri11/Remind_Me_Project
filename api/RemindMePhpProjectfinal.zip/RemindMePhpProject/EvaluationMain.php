<?php
require_once(dirname(__FILE__) . '/conf/config.php');
//cho  '/conf/config.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    switch ($_POST['op']) {
        
       

        
    

        case "Add":  
            $evaluation = new Evaluation();

            // Insert new reminder

             $evaluation->insertEvaluation($_POST["consultantId"], $_POST["userId"],$_POST["rating"],$_POST["review"],$_POST["date"] ) ;

           
          
      
            break;
        
            case "Delete":  
                $evaluation = new Evaluation();
    
                // Insert new reminder
    
                 $evaluation->deleteEvaluation($_POST["evaluationId"], $_POST["userId"]) ;
    
               
              
          
                break;
       
       

        default:
            break;
    }
    
   }
   else if ($_SERVER['REQUEST_METHOD'] == "GET") {

    switch ($_GET['op']) {
        
       
        case "LoadMyEvaluations":   
            $evaluation = new Evaluation();

           // Retrieve Evaluations by consultantId
         
           
            $evaluation->loadMyEvaluations($_GET["consultantId"]);
    
           break;
        case "loadConsultantEvaluations":   
            $evaluation = new Evaluation();

           // Retrieve Evaluations by consultantId
         
           
            $evaluation->loadConsultantEvaluations($_GET["consultantId"]);
    
           break;
  
        default:
            break;
    }
 } 
   else {
    $json = array("status" => false, "msg" => "Request method not accepted");
    include_once('close.php');
}
?>