<?php
$json = json_encode($json);
header('Content-type: application/json');
echo $json;

?>