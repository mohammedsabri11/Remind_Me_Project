<?php

class Evaluation  {

    

    public function insertEvaluation($consultantId, $userId, $rating, $review, $date) {
        $db = new Database();


       

        // Insert data into mainuser table
        $sql = "INSERT INTO evaluation (consultant_Id, user_id, Rating, Review, Date) VALUES ('$consultantId','$userId', '$rating', '$review', '$date')";
        $result = $db->executeQuery($sql);

       if ($result) 
       {
                    $response = array("status" => TRUE,"msg" => "Evaluation added successfully!");
                   
                 
                } else {
                
                    $response = array("status" => FALSE,"msg" => "Failed to add Evaluation !");
                }
           
        $this->sendResponse($response );
    }


    public function loadConsultantEvaluations($consultantId) {
        $db = new Database();
        $query = "SELECT evaluation.* ,mainuser.fullname FROM evaluation LEFT JOIN mainuser ON evaluation.user_id = mainuser.muserid WHERE consultant_Id  = '$consultantId'";
       
        
       
        $result = $db->conn->query( $query);

        $evaluations = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $evaluations[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "Data" =>  $evaluations);  
        

        $this->sendResponse($response );
    }

    public function loadMyEvaluations($consultantId) {
        $db = new Database();
        $user = new UserManager();
        $profile= $user->LoadConsultantProfile($consultantId);
        $query = "SELECT evaluation.* ,mainuser.fullname FROM evaluation LEFT JOIN mainuser ON evaluation.user_id = mainuser.muserid WHERE consultant_Id  = '$consultantId'";
        
       
        $result = $db->conn->query($query);

        $evaluations = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $evaluations[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "Data" =>  $evaluations,"profile" =>$profile);  
        

        $this->sendResponse($response );
    }

    public function deleteEvaluation($evaluationId,$userId) {
        $db = new Database();

        // Delete data from game table
        $sql = "DELETE FROM evaluation WHERE evaluationId = '$evaluationId' AND user_id = '$userId'";
        $result = $db->executeQuery($sql);

        if ($result) {
        
            $response = array("status" => TRUE,"msg" => "Evaluation deleted successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to delete Evaluation!");
        }
        $this->sendResponse($response );
    }
    public function sendResponse($response) {
        header('Content-type: application/json');
          // Convert  data to JSON
        $response = json_encode($response);
        echo $response;
    }

}

?>