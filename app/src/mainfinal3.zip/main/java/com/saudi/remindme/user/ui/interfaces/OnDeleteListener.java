package com.saudi.remindme.user.ui.interfaces;

public interface OnDeleteListener {
    void onDelete(String Comment_ID);
}
