<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CaregiverModel
 *
 * @author user
 */
class UserModel {

    private $id;
    private $fullName;

    private $gender;
    private $dob;
    private $phone;
    private $email;
    private $password;
    private $userType;



       function __construct($id,$fullName, $gender,$dob,$phone,$email, $password, $userType) {
        
         $this->fullName = $fullName;
         $this->gender = $gender;
         $this->dob = $dob;
        $this->email = $email;
        $this->password = $password;
        $this->userType= $userType;
        $this->phone= $phone;
    }
    public function getDOB() {
        return $this->dob;
    }
    public function getGender() {
        return $this->gender;
    }
    public function getPhone() {
        return $this->phone;
    }
    public function getFullName() {
        return $this->fullName;
    }
    public function getEmail() {
        return $this->email;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getUserType() {
        return $this->userType;
    }

   public function __toString() {
        
    }

}

?>