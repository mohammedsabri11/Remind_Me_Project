<?php

// Include the Database class
require_once('Database.php');

class Info
{
    public $title;
    public $instructions;
  


   


 public function getInfo1()
    {
        $db = new Database();
        // Prepare the SQL statement
        $sql = "SELECT * FROM tinfo where target=0";

        $result = $db->conn->query($sql);
        $infos = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $infos[] = $row;
            }
        }


        return $infos;    
        

      
    }
     public function getInfo2()
    {
        $db = new Database();
        // Prepare the SQL statement
        $sql = "SELECT * FROM tinfo where target=1";

        $result = $db->conn->query($sql);
        $infos = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $infos[] = $row;
            }
        }


        return $infos;    
        

      
    }
        public function getInfo3()
    {
        $db = new Database();
        // Prepare the SQL statement
        $sql = "SELECT * FROM tinfo where target=2";

        $result = $db->conn->query($sql);
        $infos = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $infos[] = $row;
            }
        }


        return $infos;    
        

      
    }
    public function getInfo()
    {
        $db = new Database();
        // Prepare the SQL statement
       $infos1=$this->getInfo1();
 $infos2=$this->getInfo2();
 $infos3=$this->getInfo3();
        $response = array("status" => TRUE, "infoList1" =>$infos1, "infoList2" =>$infos2, "infoList3" =>$infos3);    
        

        $this->sendResponse($response );
    }
    public function sendResponse($response) {
        header('Content-type: application/json');
          // Convert  data to JSON
        $response = json_encode($response);
        echo $response;
    }
}