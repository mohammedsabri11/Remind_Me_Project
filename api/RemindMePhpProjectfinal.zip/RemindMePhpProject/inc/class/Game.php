<?php
class Game {
    public $gameid;
    public $name;
    public $description;
    public $link;
    public $consultantId;

    public function __construct($gameid = null, $name = null, $description = null, $link = null, $consultantId = null) {
        $this->gameid = $gameid;
        $this->name = $name;
        $this->description = $description;
        $this->link = $link;
        $this->consultantId = $consultantId;
    }


    public function insertGame() {
        $db = new Database();

        // Insert data into game table
        $sql = "INSERT INTO game (name, description, link, consultantId) VALUES ('$this->name', '$this->description', '$this->link', '$this->consultantId')";
        $result = $db->executeQuery($sql);

        if ($result) {
          
            $response = array("status" => TRUE,"msg" => "Game inserted successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to insert game!");
        }
        $this->sendResponse($response );
    }

    public function editGame() {
        $db = new Database();

        // Update data in game table
        $sql = "UPDATE game SET name = '$this->name', description = '$this->description', link = '$this->link' WHERE gameid = '$this->gameid' AND consultantId = '$this->consultantId'";
        $result = $db->executeQuery($sql);

        if ($result) {
    
            $response = array("status" => TRUE,"msg" => "Game updated successfully!");
        } else {
         
            $response = array("status" => FALSE,"msg" => "Failed to update game!");
        }
        $this->sendResponse($response );
    }


    public function deleteGame() {
        $db = new Database();

        // Delete data from game table
        $sql = "DELETE FROM game WHERE gameid = '$this->gameid' AND consultantId = '$this->consultantId'";
        $result = $db->executeQuery($sql);

        if ($result) {
        
            $response = array("status" => TRUE,"msg" => "Game deleted successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to delete game!");
        }
        $this->sendResponse($response );
    }


    public function retrieveGamesByConsultantId() {
        $db = new Database();

        // Retrieve games by consultantId
        $sql = "SELECT * FROM game WHERE consultantId = '$this->consultantId'";
        $result = $db->conn->query($sql);

        $games = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $games[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "GameList" =>  $games);  
        

        $this->sendResponse($response );
    }

    public function addGameToUser($gameId,$userId) {
        $db = new Database();

        // Insert data into user_game table
        $sql = "INSERT INTO user_game (game_id, userId) VALUES ('$gameId', '$userId')";
        $result = $db->executeQuery($sql);

        if ($result) {
          
            $response = array("status" => TRUE,"msg" => "Game added successfully!");
        } else {
           
            $response = array("status" => FALSE,"msg" => "Failed to add game!");
        }
        $this->sendResponse($response );
    }


    public function retrieveGamesByUserId($userId) {
        $db = new Database();

        // Retrieve games by UserId
        $sql = "SELECT user_game.id ,game.name,game.description,game.link FROM user_game LEFT JOIN game ON game.gameid=user_game.game_id  WHERE user_game.userId = '$userId'";
        $result = $db->conn->query($sql);

        $games = array();
      
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $games[] = $row;
            }
           
        }

        $response = array("status" => TRUE, "GameList" =>  $games);  
        

        $this->sendResponse($response );
    }
    public function sendResponse($response) {
        header('Content-type: application/json');
          // Convert  data to JSON
        $response = json_encode($response);
        echo $response;
        
    }
}