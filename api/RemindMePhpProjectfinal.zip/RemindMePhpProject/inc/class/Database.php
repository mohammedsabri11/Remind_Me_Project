<?php

class Database {
  
   private $host = "localhost";
   private $username = "root";
   private $password = "";
   private $database = "remindmedb";

   public $conn;

   public function __construct() {
       $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);

       if ($this->conn->connect_error) {
           die("Connection failed: " . $this->conn->connect_error);
       }
   }

    protected function dbconnect() {
        return $this->conn ;
    }



    public function executeQuery($sql) {
        if ($this->conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    public function checkDuplicate($table, $field, $value) {
        $sql = "SELECT * FROM $table WHERE $field = '$value'";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            return true; // Duplicate found
        } else {
            return false; // No duplicate found
        }
    }
}
?>