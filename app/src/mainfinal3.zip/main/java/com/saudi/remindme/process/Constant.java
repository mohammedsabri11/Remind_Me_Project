package com.saudi.remindme.process;

public class Constant {
    public final static String ADMIN = "Admin";
    public final static String USER = "User";
    public final static String CONSULTANT = "Consultant";
    public final static String PROCESS_MASSEGE = "msg";
    public final static String PROCESS_STATUS = "status";
}
